from setuptools import setup

setup(
    name='ioStandard',
    version='0.1.1',
    author='Austin Gilchrist-Thomas',
    packages=['ioStandard'],
    install_requires=['pygame'],
)