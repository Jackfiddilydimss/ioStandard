from setuptools import setup

setup(
    name='ioStandard',
    version='0.1.4',
    author='Austin Gilchrist-Thomas',
    packages=['ioStandard'],
    install_requires=['pygame', 'datetime', 'tkinter'],
)